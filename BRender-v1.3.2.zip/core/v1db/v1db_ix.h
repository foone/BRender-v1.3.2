
/*
 * Copyright (c) 1993-1995 Argonaut Technologies Limited. All rights reserved.
 *
 * Extra glue for C<->ASM generated via gemasmpr.pl
 */

#ifdef __cplusplus
	extern "C" {
#endif

#ifdef __IBMC__
#endif /* __IBMC__ */

#ifdef __HIGHC__
#endif /* __IBMC__ */

#ifdef __cplusplus
	};
#endif
