/*
 * Copyright (c) 1993-1995 Argonaut Technologies Limited. All rights reserved.
 *
 * $Id: brbhook.c 1.1 1997/12/10 16:41:03 jon Exp $
 * $Locker: $
 *
 * DEfault begin/end hooks
 */
#include "brender.h"

BR_RCS_ID("$Id: brbhook.c 1.1 1997/12/10 16:41:03 jon Exp $")

void BR_CALLBACK _BrBeginHook(void)
{
}

void BR_CALLBACK _BrEndHook(void)
{
}
