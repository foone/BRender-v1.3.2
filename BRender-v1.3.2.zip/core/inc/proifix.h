/*
 * Copyright (c) 1992,1993-1995 by Argonaut Technologies Limited. All rights reserved.
 *
 * $Id: proifix.h 1.1 1997/12/10 16:41:19 jon Exp $
 * $Locker: $
 *
 */


