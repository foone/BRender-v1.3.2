/*
 * Copyright (c) 1993-1995 Argonaut Technologies Limited. All rights reserved.
 *
 * $Id: dither.c 1.1 1997/12/10 16:46:44 jon Exp $
 * $Locker: $
 *
 */

int dither[4][4] = {
    {13, 8,10, 3},
    { 1,12, 6,15},
    { 4, 9, 7,14},
    {16, 5,11, 2}
};

