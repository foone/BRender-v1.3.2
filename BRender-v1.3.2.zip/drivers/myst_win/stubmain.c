/*
 * Copyright (c) 1993-1995 Argonaut Technologies Limited. All rights reserved.
 *
 * Stub functions to hook STDIO ops.
 */
#include <windows.h>
#include <ddraw.h>

#include "drv.h"

#ifdef __DRIVER__

void main(void)
{
	return;
}

#endif

