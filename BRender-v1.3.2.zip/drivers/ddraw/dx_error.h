void Display_Error( char *string, HRESULT error );

